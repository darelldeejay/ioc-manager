import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
bind = "0.0.0.0:5000"
workers = 1
timeout = 120
